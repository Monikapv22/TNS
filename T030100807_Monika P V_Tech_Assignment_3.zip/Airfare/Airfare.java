package Airfare;
public interface Airfare {
double calculateAmount();
}