package com.tns.dayten.testing;

import org.junit.jupiter.api.Test;

public class MyFirstTest {
	
	
	@Test //basic testing annotation
	void display()
	{
		System.out.println("Hello World");
	}
	
	

}
