package com.monikapv.assignment1.Utilities;
import com.monikapv.assignment1.Employee.Developer;
import com.monikapv.assignment1.Employee.Manager;
import com.monikapv.assignment1.Utilities.EmployeeUtilities;
    
public class AssignmentMain {
	public static void main(String[] args) {
        Manager manager = new Manager("Alice Johnson", 101, 75000, "IT");
        Developer developer = new Developer("Bob Smith", 102, 65000, "Java");

        System.out.println("Before Salary Increment:");
        EmployeeUtilities.printEmployeeDetails(manager);
        EmployeeUtilities.printEmployeeDetails(developer);

        EmployeeUtilities.increaseSalary(manager, 10);
        EmployeeUtilities.increaseSalary(developer, 15);

        System.out.println("\nAfter Salary Increment:");
        EmployeeUtilities.printEmployeeDetails(manager);
        EmployeeUtilities.printEmployeeDetails(developer);
    }
}

