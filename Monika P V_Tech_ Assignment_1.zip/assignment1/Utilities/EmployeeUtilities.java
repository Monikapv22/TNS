package com.monikapv.assignment1.Utilities;
import com.monikapv.assignment1.Employee.Employee;
import com.monikapv.assignment1.Employee.Manager;
import com.monikapv.assignment1.Employee.Developer;
public class EmployeeUtilities {
	public static void increaseSalary(Employee employee, double percent) {
        double newSalary = employee.getSalary() * (1 + percent / 100);
        employee.setSalary(newSalary);
        System.out.println("Updated Salary for " + employee.getName() + ": $" + newSalary);
    }

    
    public static void printEmployeeDetails(Employee employee) {
        employee.displayInfo();
    }
}
