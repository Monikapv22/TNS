package vehicle.demo;

public class Wheel {

	
	private int wheelsize;

	public int getWheelsize() {
		return wheelsize;
	}

	public void setWheelsize(int wheelsize) {
		this.wheelsize = wheelsize;
	}

	
}
