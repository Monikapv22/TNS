package vehicle.demo;

public class Car {

	private Wheel wheelObj; //Wheel object  or reference variable

	public Wheel getWheelObj() {
		return wheelObj;
	}

	public void setWheelObj(Wheel wheelObj) {
		this.wheelObj = wheelObj;
	}
	
	
	
}
